document.addEventListener('DOMContentLoaded', () => {

    const typeFicheSelect = document.getElementById('type-fiche');

    const formulaireJoueur = document.getElementById('formulaire-joueur');

    const formulaireCoach = document.getElementById('formulaire-coach');

    const boutonCreer = document.getElementById('bouton-creer');

    

    // Inputs communs

    const logoClubInput = document.getElementById('logo-club');

    const apercuLogo = document.getElementById('apercu-logo');

    // Inputs joueur

    const nomJoueurInput = document.getElementById('nom-joueur');

    const posteJoueurSelect = document.getElementById('poste-joueur');

    const postesSecondairesJoueurSelect = document.getElementById('postes-secondaires-joueur');

    const piedFortJoueurSelect = document.getElementById('pied-fort-joueur');

    const ageJoueurInput = document.getElementById('age-joueur');

    const tailleJoueurInput = document.getElementById('taille-joueur');

    const specialitesJoueurSelect = document.getElementById('specialites-joueur');

    const potentielJoueurInput = document.getElementById('potentiel-joueur');

    const noteEvolutionInput = document.getElementById('note-evolution-joueur');

    const cpmInput = document.getElementById('cpm-joueur');

    const shoInput = document.getElementById('sho-joueur');

    const pasInput = document.getElementById('pas-joueur');

    const driInput = document.getElementById('dri-joueur');

    const defInput = document.getElementById('def-joueur');

    const phyInput = document.getElementById('phy-joueur');

    const effortEntrainementSlider = document.getElementById('effort-entrainement');

    const valeurEffortSpan = document.getElementById('valeur-effort');

    

    // Inputs coach

    const nomCoachInput = document.getElementById('nom-coach');

    const ageCoachInput = document.getElementById('age-coach');

    const palmaresCoachInput = document.getElementById('palmares-coach');

    const philosophiesCoachSelect = document.getElementById('philosophies-coach');

    const progressionJeunesCoachInput = document.getElementById('progression-jeunes-coach');

    const tactiqueCoachInput = document.getElementById('tactique-coach');

    const managementCoachInput = document.getElementById('management-coach');

    const cartesJoueursConteneur = document.getElementById('cartes-joueurs');

    const noteGlobaleEquipeDiv = document.getElementById('note-globale-equipe');

    let cartes = JSON.parse(localStorage.getItem('cartes')) || [];

    let carteEnModification = null;

    let logoData = null;

    const postes = ['G', 'DG', 'DD', 'DC', 'MDC', 'MC', 'MOC', 'AG', 'AD', 'AT', 'BU'];

    

    const specialitesParPoste = {

        'G': ['Jeu au pied', 'Sorties aériennes', 'Réflexes', 'Un contre un'],

        'DG': ['Centreur', 'Défenseur', 'Débordeur', 'Rapide'],

        'DD': ['Centreur', 'Défenseur', 'Débordeur', 'Rapide'],

        'DC': ['Défenseur', 'Solide', 'Jeu de tête', 'Relanceur'],

        'MDC': ['Récupérateur', 'Sentinelle', 'Physique', 'Organisateur'],

        'MC': ['Relanceur', 'Box-to-box', 'Tireur de loin', 'Passeur'],

        'MOC': ['Créateur de jeu', 'Tireur de loin', 'Dribbleur', 'Vison de jeu'],

        'AG': ['Dribbleur', 'Passeur', 'Centreur', 'Finisseur'],

        'AD': ['Dribbleur', 'Passeur', 'Centreur', 'Finisseur'],

        'AT': ['Finisseur', 'Tireur de loin', 'Passeur', 'Dribbleur'],

        'BU': ['Buteur', 'Finisseur', 'Renard des surfaces', 'Jeu de tête']

    };

    const peuplerMenus = () => {

        posteJoueurSelect.innerHTML = '<option value="">-- Choisir un poste --</option>';

        postes.forEach(p => {

            const option = document.createElement('option');

            option.value = p;

            option.textContent = p;

            posteJoueurSelect.appendChild(option);

        });

        postesSecondairesJoueurSelect.innerHTML = '';

        postes.forEach(p => {

            const option = document.createElement('option');

            option.value = p;

            option.textContent = p;

            postesSecondairesJoueurSelect.appendChild(option);

        });

        const philosophies = [

            'Jeu de possession', 'Contre-attaque', 'Pressing haut', 'Défense renforcée',

            'Jeu direct', 'Construction courte', 'Haute intensité', 'Bloc bas',

            'Attaque sur les ailes', 'Défense en zone', 'Marquage individuel',

            'Rotation des postes'

        ];

        philosophies.forEach(p => {

            const option = document.createElement('option');

            option.value = p;

            option.textContent = p;

            philosophiesCoachSelect.appendChild(option);

        });

        peuplerSpecialites();

    };

    const peuplerSpecialites = (postesSelectionnes = [], specialitesSelectionnees = []) => {

        specialitesJoueurSelect.innerHTML = '';

        const specialitesUniques = new Set();

        

        postesSelectionnes.forEach(poste => {

            if (specialitesParPoste[poste]) {

                specialitesParPoste[poste].forEach(spec => specialitesUniques.add(spec));

            }

        });

        const specialitesAffiches = Array.from(specialitesUniques).sort();

        specialitesAffiches.forEach(s => {

            const option = document.createElement('option');

            option.value = s;

            option.textContent = s;

            if (specialitesSelectionnees.includes(s)) {

                option.selected = true;

            }

            specialitesJoueurSelect.appendChild(option);

        });

    };

    peuplerMenus();

    const mettreAJourSpecialites = () => {

        const postePrincipal = posteJoueurSelect.value;

        const postesSecondaires = Array.from(postesSecondairesJoueurSelect.selectedOptions).map(option => option.value);

        peuplerSpecialites([postePrincipal, ...postesSecondaires]);

    };

    

    posteJoueurSelect.addEventListener('change', mettreAJourSpecialites);

    postesSecondairesJoueurSelect.addEventListener('change', mettreAJourSpecialites);

    effortEntrainementSlider.addEventListener('input', () => {

        valeurEffortSpan.textContent = effortEntrainementSlider.value;

    });

    document.querySelectorAll('.btn-note').forEach(button => {

        button.addEventListener('click', (e) => {

            const targetId = e.target.dataset.target;

            const operation = e.target.dataset.op;

            const targetInput = document.getElementById(targetId);

            let currentValue = parseInt(targetInput.value) || 0;

            if (operation === '+') {

                currentValue = Math.min(99, currentValue + 1);

            } else if (operation === '-') {

                currentValue = Math.max(0, currentValue - 1);

            }

            targetInput.value = currentValue;

        });

    });

    const lireFichierLogo = (inputElement, previewElement) => {

        const file = inputElement.files[0];

        if (file) {

            const reader = new FileReader();

            reader.onload = (event) => {

                logoData = event.target.result;

                previewElement.src = event.target.result;

                previewElement.style.display = 'block';

            };

            reader.readAsDataURL(file);

        } else {

            logoData = null;

            previewElement.src = '';

            previewElement.style.display = 'none';

        }

    };

    logoClubInput.addEventListener('change', () => lireFichierLogo(logoClubInput, apercuLogo));

    

    const sauvegarderCartes = () => {

        localStorage.setItem('cartes', JSON.stringify(cartes));

    };

    const calculerNoteGlobale = (competences, poste) => {

        const { cpm, sho, pas, dri, def, phy } = competences;

        let note;

        switch(poste.toUpperCase()) {

            case 'G': note = (def * 3 + phy * 2 + cpm) / 6; break;

            case 'DG': case 'DD': note = (def * 3 + phy * 2 + cpm + pas) / 7; break;

            case 'DC': note = (def * 3 + phy * 2 + cpm + pas) / 7; break;

            case 'MDC': note = (def * 2 + phy * 2 + pas + dri) / 6; break;

            case 'MC': note = (cpm + sho + pas + dri + def + phy) / 6; break;

            case 'MOC': note = (sho * 2 + pas * 2 + dri * 2) / 6; break;

            case 'AG': case 'AD': note = (cpm * 2 + sho + pas * 2 + dri * 2) / 7; break;

            case 'AT': case 'BU': note = (cpm + sho * 3 + pas + dri) / 6; break;

            default: note = (cpm + sho + pas + dri + def + phy) / 6;

        }

        return Math.round(note);

    };

    const calculerNoteMoyenneEquipe = () => {

        const joueurs = cartes.filter(c => c.type === 'joueur');

        if (joueurs.length === 0) {

            return 0;

        }

        const totalNotes = joueurs.reduce((sum, joueur) => {

            return sum + calculerNoteGlobale(joueur.competences, joueur.postePrincipal);

        }, 0);

        return Math.round(totalNotes / joueurs.length);

    };

    

    const mettreAJourNoteGlobaleEquipe = () => {

        const noteMoyenne = calculerNoteMoyenneEquipe();

        noteGlobaleEquipeDiv.textContent = `Note Globale de l'équipe : ${noteMoyenne}`;

    };

    const calculerEffort = (joueur, effort) => {

        const pointsParCompetence = effort / 6;

        const nouvellesCompetences = {

            cpm: Math.min(99, Math.max(0, joueur.competences.cpm + pointsParCompetence)),

            sho: Math.min(99, Math.max(0, joueur.competences.sho + pointsParCompetence)),

            pas: Math.min(99, Math.max(0, joueur.competences.pas + pointsParCompetence)),

            dri: Math.min(99, Math.max(0, joueur.competences.dri + pointsParCompetence)),

            def: Math.min(99, Math.max(0, joueur.competences.def + pointsParCompetence)),

            phy: Math.min(99, Math.max(0, joueur.competences.phy + pointsParCompetence)),

        };

        return { competences: nouvellesCompetences };

    };

    const progresserGardien = (carteId) => {

        const carte = cartes.find(c => c.id == carteId);

        if (!carte || carte.postePrincipal !== 'G') return;

        

        const noteActuelle = calculerNoteGlobale(carte.competences, carte.postePrincipal);

        const potentiel = carte.potentiel;

        if (noteActuelle >= potentiel) {

            alert("Le joueur a atteint son potentiel maximal !");

            return;

        }

        const progressionPoints = Math.random() * 2 + 1;

        const competences = carte.competences;

        const nouvelleCompetences = {};

        for (const comp in competences) {

            const nouvelleNote = Math.min(potentiel, competences[comp] + progressionPoints * Math.random());

            nouvelleCompetences[comp] = nouvelleNote;

        }

        carte.competences = nouvelleCompetences;

        sauvegarderCartes();

        afficherCartes();

        mettreAJourNoteGlobaleEquipe();

    };

    

    const genererEtoiles = (note) => {

        let etoilesHtml = '';

        for (let i = 1; i <= 3; i++) {

            etoilesHtml += `<span class="etoile ${i <= note ? 'remplie' : ''}">&#9733;</span>`;

        }

        return etoilesHtml;

    };

    const creerFicheJoueur = (joueur) => {

        const carte = document.createElement('div');

        carte.classList.add('carte-joueur');

        carte.dataset.id = joueur.id;

        

        const noteGlobale = calculerNoteGlobale(joueur.competences, joueur.postePrincipal);

        const specialitesHTML = joueur.specialites && joueur.specialites.length > 0 ? `<div class="specialites-joueur">Spécialités : ${joueur.specialites.join(', ')}</div>` : '';

        const postesSecondairesHTML = joueur.postesSecondaires && joueur.postesSecondaires.length > 0 ? `<div class="postes-secondaires-joueur">Postes secondaires : ${joueur.postesSecondaires.join(', ')}</div>` : '';

        const boutonProgressionHTML = joueur.postePrincipal === 'G' ? 

            `<button class="bouton-progresser" data-id="${joueur.id}">Faire progresser</button>` : '';

        

        const etoilesHTML = genererEtoiles(joueur.noteEvolution);

        carte.innerHTML = `

            <button class="bouton-supprimer" data-id="${joueur.id}">&#x2715;</button>

            <div class="entete-carte">

                <div class="note-hexagone">

                    <span class="note-globale">${noteGlobale}</span>

                </div>

                <div class="etoiles-progression">${etoilesHTML}</div>

            </div>

            <div class="contenu">

                <div class="centrage-contenu">

                    <img src="${joueur.logoData || ''}" alt="Logo Club" class="logo-club">

                    <div class="nom-joueur">${joueur.nom.toUpperCase()}</div>

                    <div class="poste-joueur">${joueur.postePrincipal.toUpperCase()}</div>

                </div>

                <div class="attributs">

                    <div class="attribut">

                        <span class="label-attribut">CPM</span>

                        <span class="valeur-attribut">${Math.round(joueur.competences.cpm)}</span>

                    </div>

                    <div class="attribut">

                        <span class="label-attribut">SHO</span>

                        <span class="valeur-attribut">${Math.round(joueur.competences.sho)}</span>

                    </div>

                    <div class="attribut">

                        <span class="label-attribut">PAS</span>

                        <span class="valeur-attribut">${Math.round(joueur.competences.pas)}</span>

                    </div>

                    <div class="attribut">

                        <span class="label-attribut">DRI</span>

                        <span class="valeur-attribut">${Math.round(joueur.competences.dri)}</span>

                    </div>

                    <div class="attribut">

                        <span class="label-attribut">DEF</span>

                        <span class="valeur-attribut">${Math.round(joueur.competences.def)}</span>

                    </div>

                    <div class="attribut">

                        <span class="label-attribut">PHY</span>

                        <span class="valeur-attribut">${Math.round(joueur.competences.phy)}</span>

                    </div>

                </div>

                <div class="nouvelles-categories">

                    <div class="info-supplementaire">Pied fort : <span>${joueur.piedFort}</span></div>

                    <div class="info-supplementaire">Potentiel : <span>${joueur.potentiel}</span></div>

                    <div class="info-supplementaire">Âge : <span>${joueur.age} ans</span></div>

                    <div class="info-supplementaire">Taille : <span>${joueur.taille} cm</span></div>

                    ${postesSecondairesHTML}

                    ${specialitesHTML}

                </div>

            </div>

            <div class="actions-carte">

                ${boutonProgressionHTML}

                <button class="bouton-modifier" data-id="${joueur.id}">Modifier</button>

                <button class="bouton-partager" data-id="${joueur.id}">Partager</button>

            </div>

        `;

        return carte;

    };

    const creerFicheCoach = (coach) => {

        const carte = document.createElement('div');

        carte.classList.add('carte-coach');

        carte.dataset.id = coach.id;

        const philosophiesHTML = coach.philosophies && coach.philosophies.length > 0 ? `<div class="philosophies-coach">Philosophies : ${coach.philosophies.join(', ')}</div>` : '';

        const palmaresHTML = coach.palmares && coach.palmares.length > 0 ? `<div class="info-supplementaire">Palmarès : <span>${coach.palmares.join(', ')}</span></div>` : '';

        

        carte.innerHTML = `

            <button class="bouton-supprimer" data-id="${coach.id}">&#x2715;</button>

            <div class="entete-carte">

                <img src="${coach.logoData || ''}" alt="Logo Club" class="logo-club">

            </div>

            <div class="contenu">

                <div class="centrage-contenu" style="margin-top: 0;">

                    <div class="nom-coach">${coach.nom.toUpperCase()}</div>

                    <div class="info-supplementaire" style="text-align: center;">Âge : <span>${coach.age} ans</span></div>

                </div>

                <div class="attributs" style="margin-top: 10px;">

                    <div class="attribut">

                        <span class="label-attribut">Tactique</span>

                        <span class="valeur-attribut">${coach.tactique}</span>

                    </div>

                    <div class="attribut">

                        <span class="label-attribut">Management</span>

                        <span class="valeur-attribut">${coach.management}</span>

                    </div>

                    <div class="attribut" style="grid-column: span 2;">

                        <span class="label-attribut">Prog. Jeunes</span>

                        <span class="valeur-attribut">${coach.progressionJeunes}</span>

                    </div>

                </div>

                <div class="nouvelles-categories">

                    ${palmaresHTML}

                    ${philosophiesHTML}

                </div>

            </div>

            <div class="actions-carte">

                <button class="bouton-modifier" data-id="${coach.id}">Modifier</button>

                <button class="bouton-partager" data-id="${coach.id}">Partager</button>

            </div>

        `;

        return carte;

    };

    

    const afficherCartes = () => {

        cartesJoueursConteneur.innerHTML = '';

        cartes.forEach(carte => {

            let elementCarte;

            if (carte.type === 'joueur') {

                elementCarte = creerFicheJoueur(carte);

            } else if (carte.type === 'coach') {

                elementCarte = creerFicheCoach(carte);

            }

            if (elementCarte) {

                cartesJoueursConteneur.appendChild(elementCarte);

            }

        });

        

        document.querySelectorAll('.bouton-supprimer').forEach(button => {

            button.addEventListener('click', (e) => {

                e.stopPropagation();

                const carteId = e.target.dataset.id;

                supprimerCarte(carteId);

            });

        });

        

        document.querySelectorAll('.bouton-modifier').forEach(button => {

            button.addEventListener('click', (e) => {

                e.stopPropagation();

                const carteId = e.target.dataset.id;

                chargerCartePourModification(carteId);

            });

        });

        

        document.querySelectorAll('.bouton-progresser').forEach(button => {

            button.addEventListener('click', (e) => {

                e.stopPropagation();

                const carteId = e.target.dataset.id;

                progresserGardien(carteId);

            });

        });

        document.querySelectorAll('.bouton-partager').forEach(button => {

            button.addEventListener('click', (e) => {

                e.stopPropagation();

                const carteElement = e.target.closest('.carte-joueur') || e.target.closest('.carte-coach');

                if (carteElement) {

                    partagerCarte(carteElement.dataset.id);

                }

            });

        });

        mettreAJourNoteGlobaleEquipe();

    };

    

    const chargerCartePourModification = (id) => {

        const carte = cartes.find(c => c.id == id);

        if (!carte) return;

        carteEnModification = carte;

        boutonCreer.textContent = 'Mettre à jour';

        typeFicheSelect.value = carte.type;

        toggleFormulaire(carte.type, false);

        logoData = carte.logoData;

        apercuLogo.src = logoData || '';

        apercuLogo.style.display = logoData ? 'block' : 'none';

        if (carte.type === 'joueur') {

            nomJoueurInput.value = carte.nom;

            posteJoueurSelect.value = carte.postePrincipal;

            ageJoueurInput.value = carte.age;

            tailleJoueurInput.value = carte.taille;

            

            Array.from(postesSecondairesJoueurSelect.options).forEach(option => {

                option.selected = carte.postesSecondaires && carte.postesSecondaires.includes(option.value);

            });

            

            peuplerSpecialites([carte.postePrincipal, ...carte.postesSecondaires], carte.specialites);

            

            piedFortJoueurSelect.value = carte.piedFort;

            potentielJoueurInput.value = carte.potentiel;

            noteEvolutionInput.value = carte.noteEvolution || 0;

            cpmInput.value = Math.round(carte.competences.cpm);

            shoInput.value = Math.round(carte.competences.sho);

            pasInput.value = Math.round(carte.competences.pas);

            driInput.value = Math.round(carte.competences.dri);

            defInput.value = Math.round(carte.competences.def);

            phyInput.value = Math.round(carte.competences.phy);

            effortEntrainementSlider.value = 0;

            valeurEffortSpan.textContent = 0;

            

        } else if (carte.type === 'coach') {

            nomCoachInput.value = carte.nom;

            ageCoachInput.value = carte.age;

            palmaresCoachInput.value = carte.palmares ? carte.palmares.join(', ') : '';

            Array.from(philosophiesCoachSelect.options).forEach(option => {

                option.selected = carte.philosophies && carte.philosophies.includes(option.value);

            });

            progressionJeunesCoachInput.value = carte.progressionJeunes;

            tactiqueCoachInput.value = carte.tactique;

            managementCoachInput.value = carte.management;

        }

    };

    const handleCreationCarte = () => {

        const typeFiche = typeFicheSelect.value;

        let nouvelleCarte = {};

        if (typeFiche === 'joueur') {

            const nom = nomJoueurInput.value;

            const postePrincipal = posteJoueurSelect.value;

            const piedFort = piedFortJoueurSelect.value;

            const potentiel = parseInt(potentielJoueurInput.value) || 0;

            const noteEvolution = parseInt(noteEvolutionInput.value) || 0;

            const age = parseInt(ageJoueurInput.value) || 0;

            const taille = parseInt(tailleJoueurInput.value) || 0;

            const postesSecondaires = Array.from(postesSecondairesJoueurSelect.selectedOptions).map(option => option.value);

            const specialites = Array.from(specialitesJoueurSelect.selectedOptions).map(option => option.value);

            const competences = {

                cpm: parseInt(cpmInput.value) || 0, sho: parseInt(shoInput.value) || 0,

                pas: parseInt(pasInput.value) || 0, dri: parseInt(driInput.value) || 0,

                def: parseInt(defInput.value) || 0, phy: parseInt(phyInput.value) || 0,

            };

            if (nom === '' || postePrincipal === '' || piedFort === '') {

                alert('Veuillez remplir le nom, le poste principal et le pied fort du joueur.');

                return;

            }

            nouvelleCarte = {

                type: 'joueur', id: Date.now(), nom, logoData, potentiel, noteEvolution, piedFort, specialites,

                postesSecondaires, postePrincipal, competences, age, taille

            };

        } else if (typeFiche === 'coach') {

            const nom = nomCoachInput.value;

            const age = parseInt(ageCoachInput.value) || 0;

            const palmares = palmaresCoachInput.value.split(',').map(item => item.trim()).filter(item => item !== '');

            const philosophies = Array.from(philosophiesCoachSelect.selectedOptions).map(option => option.value);

            const progressionJeunes = parseInt(progressionJeunesCoachInput.value) || 0;

            const tactique = parseInt(tactiqueCoachInput.value) || 0;

            const management = parseInt(managementCoachInput.value) || 0;

            

            if (nom === '') {

                alert('Veuillez remplir le nom du coach.');

                return;

            }

            nouvelleCarte = {

                type: 'coach', id: Date.now(), nom, age, logoData, palmares, philosophies, progressionJeunes, tactique, management

            };

        }

        if (carteEnModification) {

            const index = cartes.findIndex(c => c.id == carteEnModification.id);

            if (index !== -1) {

                if (carteEnModification.type === 'joueur') {

                    const resultatEffort = calculerEffort(cartes[index], parseInt(effortEntrainementSlider.value));

                    nouvelleCarte.competences = resultatEffort.competences;

                }

                cartes[index] = { ...cartes[index], ...nouvelleCarte, logoData };

            }

            carteEnModification = null;

            boutonCreer.textContent = 'Créer la fiche';

        } else {

            cartes.push(nouvelleCarte);

        }

        sauvegarderCartes();

        afficherCartes();

        resetFormulaire();

    };

    

    const supprimerCarte = (id) => {

        cartes = cartes.filter(carte => carte.id != id);

        sauvegarderCartes();

        afficherCartes();

    };

    const partagerCarte = (id) => {

        const carteElement = document.querySelector(`.carte-joueur[data-id="${id}"]`) || document.querySelector(`.carte-coach[data-id="${id}"]`);

        if (carteElement) {

            const carteACapturer = carteElement.cloneNode(true);

            const boutons = carteACapturer.querySelector('.actions-carte');

            if (boutons) boutons.remove();

            

            const boutonSupprimer = carteACapturer.querySelector('.bouton-supprimer');

            if (boutonSupprimer) boutonSupprimer.remove();

            

            const nomFichier = cartes.find(c => c.id == id).nom;

            document.body.appendChild(carteACapturer);

            

            html2canvas(carteACapturer, { backgroundColor: '#1a1a1a' }).then(canvas => {

                const image = canvas.toDataURL('image/png');

                const link = document.createElement('a');

                link.download = `carte_${nomFichier}.png`;

                link.href = image;

                link.click();

                carteACapturer.remove();

            }).catch(err => {

                console.error("Erreur lors de la capture de l'image", err);

                carteACapturer.remove();

            });

        }

    };

    

    const toggleFormulaire = (type, reinitialiser = true) => {

        if (type === 'joueur') {

            formulaireJoueur.style.display = 'block';

            formulaireCoach.style.display = 'none';

            if (reinitialiser) resetFormulaireCoach();

        } else if (type === 'coach') {

            formulaireJoueur.style.display = 'none';

            formulaireCoach.style.display = 'block';

            if (reinitialiser) resetFormulaireJoueur();

        }

    };

    const resetFormulaireJoueur = () => {

        nomJoueurInput.value = '';

        posteJoueurSelect.selectedIndex = 0;

        piedFortJoueurSelect.selectedIndex = 0;

        ageJoueurInput.value = '20';

        tailleJoueurInput.value = '180';

        potentielJoueurInput.value = '50';

        noteEvolutionInput.value = '0';

        cpmInput.value = '';

        shoInput.value = '';

        pasInput.value = '';

        driInput.value = '';

        defInput.value = '';

        phyInput.value = '';

        effortEntrainementSlider.value = '0';

        valeurEffortSpan.textContent = '0';

        Array.from(postesSecondairesJoueurSelect.options).forEach(option => option.selected = false);

        peuplerSpecialites();

    };

    

    const resetFormulaireCoach = () => {

        nomCoachInput.value = '';

        ageCoachInput.value = '40';

        palmaresCoachInput.value = '';

        progressionJeunesCoachInput.value = '75';

        tactiqueCoachInput.value = '70';

        managementCoachInput.value = '70';

        Array.from(philosophiesCoachSelect.options).forEach(option => option.selected = false);

    };

    

    const resetFormulaire = () => {

        const typeFiche = typeFicheSelect.value;

        if (typeFiche === 'joueur') {

            resetFormulaireJoueur();

        } else if (typeFiche === 'coach') {

            resetFormulaireCoach();

        }

        logoClubInput.value = '';

        apercuLogo.style.display = 'none';

        logoData = null;

        boutonCreer.textContent = 'Créer la fiche';

        carteEnModification = null;

    };

    typeFicheSelect.addEventListener('change', (e) => toggleFormulaire(e.target.value));

    boutonCreer.addEventListener('click', handleCreationCarte);

    afficherCartes();

});

